# Setup Guide - YouTube Abuse Trends Dashboard

Complete installation and configuration guide for running the project.

---

## ⚙️ Prerequisites

### System Requirements
- **Operating System:** Windows 10+, macOS 10.15+, or Linux (Ubuntu 20.04+)
- **Python:** Version 3.8 or higher
- **RAM:** 4GB minimum (8GB recommended for large datasets)
- **Disk Space:** 500MB for project + dependencies

### Required Accounts
1. **Google Cloud Platform** (for YouTube API access)
   - Free tier available
   - Credit card required (not charged for API usage within quota)

2. **Tableau Public** (for dashboard visualization)
   - Free account
   - No credit card required

---

## 📥 Installation Steps

### Step 1: Clone the Repository

```bash
# Using HTTPS
git clone https://github.com/yourname/youtube-abuse-dashboard.git
cd youtube-abuse-dashboard

# OR using SSH
git clone git@github.com:yourname/youtube-abuse-dashboard.git
cd youtube-abuse-dashboard
```

### Step 2: Set Up Python Environment

#### Option A: Using venv (Recommended)
```bash
# Create virtual environment
python3 -m venv venv

# Activate environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

#### Option B: Using conda
```bash
# Create conda environment
conda create -n youtube-abuse python=3.9
conda activate youtube-abuse

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Verify Installation

```bash
# Check Python version
python --version
# Should output: Python 3.8.x or higher

# Test imports
python -c "import pandas; import googleapiclient; print('✓ All dependencies installed')"
```

---

## 🔑 YouTube API Setup

### Step-by-Step API Configuration

#### 1. Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click "Select a Project" → "New Project"
3. Project Name: `youtube-abuse-dashboard`
4. Click "Create"

#### 2. Enable YouTube Data API v3

1. In Cloud Console, go to **APIs & Services** → **Library**
2. Search for "YouTube Data API v3"
3. Click on it → Click "Enable"

#### 3. Create API Credentials

1. Go to **APIs & Services** → **Credentials**
2. Click **"+ CREATE CREDENTIALS"** → **API key**
3. Your API key will be generated (looks like: `AIzaSyD...`)
4. **IMPORTANT:** Restrict your API key:
   - Click on the API key name
   - Under "API restrictions":
     - Select "Restrict key"
     - Choose "YouTube Data API v3"
   - Click "Save"

#### 4. Understand API Quotas

**Free Tier Limits:**
- 10,000 units per day
- Each comment fetch = 1 unit
- Each video detail fetch = 1 unit

**For this project:**
- Analyzing 5 videos with 100 comments each = ~505 units
- You can run the script ~20 times per day within free quota

### Step 4: Configure API Key

#### Option A: Environment Variable (Recommended)

```bash
# On macOS/Linux (add to ~/.bashrc or ~/.zshrc for persistence)
export YOUTUBE_API_KEY='your_api_key_here'

# On Windows (PowerShell)
$env:YOUTUBE_API_KEY='your_api_key_here'

# Verify
echo $YOUTUBE_API_KEY  # macOS/Linux
echo $env:YOUTUBE_API_KEY  # Windows
```

#### Option B: Using .env File

```bash
# Create .env file in project root
echo "YOUTUBE_API_KEY=your_api_key_here" > .env

# The scripts will automatically load from .env
```

#### Option C: Direct Edit (Not Recommended for Security)

Edit `01_data_collection.py`:
```python
class Config:
    API_KEY = 'your_api_key_here'  # Replace with your actual key
```

---

## 🚀 Running the Project

### Full Workflow

#### Step 1: Data Collection
```bash
python 01_data_collection.py
```

**Expected Output:**
```
================================================================================
YOUTUBE ABUSE TRENDS DASHBOARD - DATA COLLECTION
Real-Time Platform Manipulation Detection System
================================================================================

[STEP 1] Initializing database...
✓ Database initialized successfully

[STEP 2] Connecting to YouTube API...
✓ Connected successfully

[STEP 3] Fetching trending videos (News & Politics category)...
✓ Fetched 5 videos

[STEP 4] Analyzing comments for abuse patterns...

  [1/5] Processing: Breaking News: Major Policy Announcement...
    ✓ Analyzed 100 comments
    📊 Spam detected: 12 (12.0%)
    ⚡ Velocity: 2.34 comments/min

================================================================================
✅ DATA COLLECTION COMPLETE
================================================================================

Database saved to: youtube_abuse_trends.db
```

#### Step 2: SQL Analysis
```bash
python 02_sql_analysis.py
```

**Expected Output:**
- 7 SQL query results displayed
- Executive summary metrics
- 3 CSV files exported for Tableau

#### Step 3: Tableau Dashboard (Manual)

1. Open Tableau Public Desktop
2. **Connect to Data:**
   - Data → Connect → Text File
   - Select `tableau_video_metrics.csv`
3. **Add Additional Data Sources:**
   - Data → New Data Source
   - Add `tableau_comment_details.csv` and `tableau_timeseries.csv`
4. **Create Visualizations:**
   - Follow `docs/TABLEAU_GUIDE.md` for specific chart instructions

---

## 🔧 Troubleshooting

### Common Issues

#### Issue 1: "ImportError: No module named 'googleapiclient'"

**Solution:**
```bash
pip install --upgrade google-api-python-client
```

#### Issue 2: "HttpError 403: The request cannot be completed because you have exceeded your quota"

**Solution:**
- You've hit the 10,000 units/day limit
- Wait until midnight PST for quota reset
- OR reduce `MAX_COMMENTS_PER_VIDEO` in Config class

#### Issue 3: "HttpError 403: Comments are disabled for this video"

**Solution:**
- This is normal - some videos disable comments
- The script automatically skips these
- Try a different video category if needed

#### Issue 4: API Key Not Recognized

**Solution:**
```bash
# Verify environment variable is set
python -c "import os; print(os.getenv('YOUTUBE_API_KEY'))"

# If output is 'None', re-export:
export YOUTUBE_API_KEY='your_key'
```

#### Issue 5: Database Locked Error

**Solution:**
```bash
# Close any programs accessing the database
# Delete and regenerate:
rm youtube_abuse_trends.db
python 01_data_collection.py
```

---

## 📊 Sample Data (No API Key Required)

If you don't have access to YouTube API, use the provided sample dataset:

```bash
# Download sample database
wget https://github.com/yourname/youtube-abuse-dashboard/raw/main/data/sample_data.db
mv sample_data.db youtube_abuse_trends.db

# Run analysis on sample data
python 02_sql_analysis.py
```

---

## 🧪 Testing

### Run Unit Tests
```bash
pytest tests/
```

### Validate Data Quality
```bash
python -c "import sqlite3; conn = sqlite3.connect('youtube_abuse_trends.db'); print('Rows:', conn.execute('SELECT COUNT(*) FROM comments').fetchone()[0])"
```

---

## 📚 Additional Resources

### YouTube API Documentation
- [Official Docs](https://developers.google.com/youtube/v3)
- [Python Client Library](https://github.com/googleapis/google-api-python-client)
- [Quota Calculator](https://developers.google.com/youtube/v3/determine_quota_cost)

### SQL Resources
- [SQLite Tutorial](https://www.sqlitetutorial.net/)
- [SQL Window Functions](https://mode.com/sql-tutorial/sql-window-functions/)

### Tableau Resources
- [Tableau Public Gallery](https://public.tableau.com/gallery/)
- [Free Training Videos](https://www.tableau.com/learn/training/20201)

---

## 🆘 Getting Help

### GitHub Issues
Open an issue: [github.com/yourname/youtube-abuse-dashboard/issues](https://github.com/yourname/youtube-abuse-dashboard/issues)

### Contact
- Email: your.email@gmail.com
- LinkedIn: [linkedin.com/in/yourname](https://linkedin.com/in/yourname)

---

## ✅ Checklist

Before starting, ensure you have:
- [ ] Python 3.8+ installed
- [ ] Git installed
- [ ] Google Cloud account created
- [ ] YouTube Data API v3 enabled
- [ ] API key obtained and configured
- [ ] Virtual environment activated
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] Tableau Public installed (for dashboard)

---

**Ready to start? Run:**
```bash
python 01_data_collection.py
```

Good luck! 🚀
